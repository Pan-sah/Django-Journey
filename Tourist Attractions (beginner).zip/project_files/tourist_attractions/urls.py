from django.urls import path

from . import views

urlpatterns = [
  path("", views.home, name="home"),
  path("details/<statename>", views.details, name="details"),
  path("create/state/", views.StateCreate.as_view(), name="statecreate"),
  path("create/attraction/", views.AttractionCreate.as_view(), name="attractioncreate"),
]